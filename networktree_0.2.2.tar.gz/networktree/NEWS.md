# networktree 0.2.1

* bug fix for plots, fill lower triangular of matrix first
* dots of plot method now parsed to terminal layout
* fixed a bug when using different data types in nodevars & splitvars
* added 'getnetwork' function to easily extract networks

# networktree 0.2.2

* bug fix for plotting in new devices
* comparetree function added for easy comparison between two nodes
* suppress warnings from EBICglasso
